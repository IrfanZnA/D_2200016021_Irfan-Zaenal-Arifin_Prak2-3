import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:rebuild_app/app_state.dart';
import 'package:rebuild_app/components/big_card.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var appState = context.watch<Appstate>(); 
    var pair  = appState.current;

    IconData icon;
    if (appState.favorites.contains(pair)) {
      icon = Icons.favorite;
    } else {
      icon = Icons.favorite_border;
    }
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("A randomAWESOME idea : "),
            BigCard(pair: pair),
            const SizedBox(height: 10), 
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                ElevatedButton.icon(
                  onPressed: () {
                    appState.togglefavorite();
                  },
                  label: const Text('Like'),
                  icon: Icon(icon),
                ),
                const SizedBox(width: 15),
                ElevatedButton(
                  onPressed: () {
                    appState.getNext();
                  },
                  child: const Text('next'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

