import 'package:flutter/material.dart';
import 'package:rebuild_app/app_bar.dart'; 
import 'package:rebuild_app/app_state.dart';
import 'package:rebuild_app/home_page.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => Appstate(),
      child: MaterialApp(
        title: "Namer App",
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSwatch(
            primarySwatch: Colors.deepOrange,
          ),
        ),
        home: Scaffold(
          appBar: MyAppBar(), 
          body: const HomePage(),
        ),
      ),
    );
  }
}
